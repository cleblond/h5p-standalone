import { H5PStandalone } from "./h5p-standalone";
declare const _default: {
    H5P: typeof H5PStandalone;
};
export default _default;
