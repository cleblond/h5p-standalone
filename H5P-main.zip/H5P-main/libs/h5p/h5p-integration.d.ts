import { H5PIntegration } from './h5p';
export declare function defaultH5PIntegration(): H5PIntegration;
